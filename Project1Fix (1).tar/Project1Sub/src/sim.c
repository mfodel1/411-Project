#include <stdio.h>
#include <stdint.h>
#include "shell.h"

/* process_instruction() is implemented at the bottom of the file as it calls files that are not defined yet*/
/* all following functions will be called by process_instruction() */ 

/* this function is used to create a mask of bits in order to isolate the different bits inside of things
   like the instruction to be processed.  */ 
uint32_t mask(unsigned x, unsigned y){
  uint32_t shift = 0;
  for (unsigned i = x; i <= y; i++){
    shift |= 1 << i; 
  } // sets the specified bits to 1's

  return shift;
}

/* processes the special type instruction */
void special(uint32_t instruction, unsigned convert){
  uint32_t temp = mask(0, 5);
  unsigned instrName = temp & instruction;
  unsigned sa, rd, rt, rs, lowOrder;
  int64_t result; // used in MULT
  int32_t resultD; //used in DIV
  uint32_t lo; 
  uint64_t hi; 
  switch(instrName){
  case 12: //SYSCALL
    if (CURRENT_STATE.REGS[2] == 10){
      RUN_BIT = 0;
      return;
    }
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 0:
    temp = mask(6, 10);
    sa = temp & instruction;
    sa = sa >> 6;
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] << sa;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 2:
    temp = mask(6, 10);
    sa = temp & instruction;
    sa = sa >> 6;
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction; 
    rt = rt >> 16;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] >> sa;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 3:
    temp = mask(6, 10);
    sa = temp & instruction;
    sa = sa >> 6;
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction; 
    rt = rt >> 16;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] >> sa;
    NEXT_STATE.REGS[rd] = (int32_t)CURRENT_STATE.REGS[rd]; // sign extends the high-order bits
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 4:
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    temp = mask(0, 4);
    lowOrder = temp & CURRENT_STATE.REGS[rs];
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] << lowOrder; // shifted left by the low-order 5 bits in rs
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 6:
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    temp = mask(0, 4);
    lowOrder = temp & CURRENT_STATE.REGS[rs];
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] >> lowOrder; // shifted right by the low-order 5 bits rs
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 7:
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    temp = mask(0, 4);
    lowOrder = temp & CURRENT_STATE.REGS[rs];
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] >> lowOrder; // shifted left by the low-order 5 bits in rs
    NEXT_STATE.REGS[rd] = (int32_t)CURRENT_STATE.REGS[rd]; // sign extends the high order bits
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 8:// JR
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21; 
    NEXT_STATE.PC = CURRENT_STATE.REGS[rs];
    break;
  case 9:
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.PC = CURRENT_STATE.REGS[rs];
    NEXT_STATE.REGS[31] = CURRENT_STATE.PC + 4;
    break;
  case 32: // ADD
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] + CURRENT_STATE.REGS[rs];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 33: // ADDU, no different than ADD, since exceptions are not cared about in this project.
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rt] + CURRENT_STATE.REGS[rs];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
  case 34: // SUB
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rs] - CURRENT_STATE.REGS[rt];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 35: //SUBU
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rs] - CURRENT_STATE.REGS[rt];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 36: //AND
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rs] & CURRENT_STATE.REGS[rt];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 37: //OR
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rs] | CURRENT_STATE.REGS[rt];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 38: //XOR
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[rs] ^ CURRENT_STATE.REGS[rt];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 39: //NOR
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[rd] = !(CURRENT_STATE.REGS[rs] | CURRENT_STATE.REGS[rt]);
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 42: // SLT
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    int rsc = CURRENT_STATE.REGS[rs];
    int rtc = CURRENT_STATE.REGS[rt];
    if (rsc < rtc)
      NEXT_STATE.REGS[rd] = 1;
    else
      NEXT_STATE.REGS[rd] = 0;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 43: //SLTU
     temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    if (CURRENT_STATE.REGS[rs] < CURRENT_STATE.REGS[rt])
      NEXT_STATE.REGS[rd] = 1;
    else
      NEXT_STATE.REGS[rd] = 0;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 24: //MULT
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    result = CURRENT_STATE.REGS[rs] * CURRENT_STATE.REGS[rt];
    temp = mask(0, 31); //gets the low order word
    lo = temp & result;
    temp = 0;
    temp = (int64_t)temp; 
    for (unsigned i = 32; i <= 64; i++) { //gets the high order word
      temp |= 1 << i;
    }
    hi = temp & instruction;
    hi = hi >> 32;
    hi = (uint32_t)hi; 
    NEXT_STATE.REGS[CURRENT_STATE.LO] = lo;
    NEXT_STATE.REGS[CURRENT_STATE.HI] = hi;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 16: //MFHI
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[CURRENT_STATE.HI];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 18://MFLO
    temp = mask(11, 15);
    rd = temp & instruction;
    rd = rd >> 11;
    NEXT_STATE.REGS[rd] = CURRENT_STATE.REGS[CURRENT_STATE.LO];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 17://MTHI
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[NEXT_STATE.HI] = CURRENT_STATE.REGS[rs];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 19://MTLO
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    NEXT_STATE.REGS[NEXT_STATE.LO] = CURRENT_STATE.REGS[rs];
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 25: //MULTU
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    result = CURRENT_STATE.REGS[rs] * CURRENT_STATE.REGS[rt]; // could be greater than 32 bits
    temp = mask(0, 31); //gets the low order word
    lo = temp & result;
    temp = 0;
    temp = (int64_t)temp; 
    for (unsigned i = 32; i <= 64; i++) { //gets the high order word
      temp |= 1 << i;
    }
    hi = temp & instruction;
    hi = hi >> 32;
    hi = (uint32_t)hi; 
    NEXT_STATE.REGS[CURRENT_STATE.LO] = lo;
    NEXT_STATE.REGS[CURRENT_STATE.HI] = hi;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 26://DIV
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    resultD = CURRENT_STATE.REGS[rs] / CURRENT_STATE.REGS[rt]; //32 bit result
    NEXT_STATE.REGS[CURRENT_STATE.LO] = resultD; //quotient
    NEXT_STATE.REGS[CURRENT_STATE.HI] = CURRENT_STATE.REGS[rs] % CURRENT_STATE.REGS[rt]; // remainder
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 27: //DIVU
    temp = mask(16, 20);
    rt = temp & instruction;
    rt = rt >> 16;
    temp = mask(21, 25);
    rs = temp & instruction;
    rs = rs >> 21;
    resultD = CURRENT_STATE.REGS[rs] / CURRENT_STATE.REGS[rt]; // 32 bit result 
    NEXT_STATE.REGS[CURRENT_STATE.LO] = result; //quotient
    NEXT_STATE.REGS[CURRENT_STATE.HI] = CURRENT_STATE.REGS[rs] % CURRENT_STATE.REGS[rt]; // remainder
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  }
  return;
}

/* processes the register Immediate instructions, BLTZ, BGEZ, BLTZAL, BGEZAL */
void regImm(uint32_t instruction, unsigned convert){
  uint32_t temp = mask(16, 20);
  unsigned instructionDec = temp & instruction; // Decode the instruction  
  instructionDec = instructionDec >> 16;
  temp = mask(0, 15);
  unsigned offset = temp & instruction;
  offset = offset << 2;  // every instruction calls for the same operations to be done on the offset 
  offset = (int)offset;
  temp = mask(21, 25);
  unsigned rs = temp & instruction;
  rs = rs >> 21; 
  switch(instructionDec){ /* every instruction description implemented here is described to use the sum of the
			  offset and the address of the instruction in the delay slot, since this project is
			  not using delay slots, the new target address is simply the offset that was sign
			  extended and shifted to the left 2 bits */ 
  case 1: //BGEZ 
    if (CURRENT_STATE.REGS[rs] == 0)
      NEXT_STATE.PC = offset;
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 34: //BGEZAL
    NEXT_STATE.REGS[31] = CURRENT_STATE.PC + 4;
    if (CURRENT_STATE.REGS[rs] == 0)
      NEXT_STATE.PC = offset; 
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 0: // BLTZ
    if (CURRENT_STATE.REGS[rs] < 0)
      NEXT_STATE.PC = offset;
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 32: //BLTZAL
    NEXT_STATE.REGS[31] = CURRENT_STATE.PC + 4;
    if (CURRENT_STATE.REGS[rs] < 0)
      NEXT_STATE.PC =  offset;
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  }
  return;
}

/* processes the 3 store instructions, sign extends and adds the 16 bit offset and stores a certain size of
   data based on what the instruction specifies.  */
void store(uint32_t instruction, unsigned convert){
  uint32_t result;
  int shift = 0;
  uint32_t temp = mask(0, 15);
  unsigned offset = temp & instruction;
  offset = (int)offset;
  temp = mask(21, 25);
  unsigned base = temp & instruction;
  base = base >> 21;
  unsigned address = CURRENT_STATE.REGS[base] + offset;
  temp = mask(16, 20);
  unsigned regT = temp & instruction;
  regT = regT >> 16;
  /* once the instruction is decoded into variables, pick how much of the regT to store in the effective 
     address based on the instruction. */ 
  switch(convert){
  case 40:
    temp = mask(24, 31);
    shift = 24;
    break;
  case 41:
    temp = mask(16, 31);
    shift = 16;
    break; 
  case 43:
    temp = mask(0,31);
    shift = 0;
    break;
  }
  result = temp & CURRENT_STATE.REGS[regT];
  result = result >> shift;
  mem_write_32(address, result);
  NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
  return;
}

/* processes the various load instructions */
void load(uint32_t instruction, unsigned convert){
  /* add the offset to the contents of the base register and the contents in memory location address are 
     loaded into the target register */
  uint32_t temp = mask(0, 15);
  unsigned offset = temp & instruction;
  offset = (int)offset;
  temp = mask(21, 25);
  unsigned base = temp & instruction;
  base = base >> 21; 
  unsigned address = CURRENT_STATE.REGS[base] + offset;
  uint32_t memory = mem_read_32(address);
  temp = mask(16, 20);
  unsigned regT = temp & instruction;
  regT = regT >> 16; 
  unsigned result;
  /* loads the correct length of the memory location into the target register */ 
  switch(convert){
  case 32:
    temp = mask(24, 31);
    result = temp & memory;
    result = result >> 24; 
    result = (int)result;
    NEXT_STATE.REGS[regT] = result;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 33:
    temp = mask(16, 31);
    result = temp & memory;
    result = result >> 16;
    result = (int)result;
    NEXT_STATE.REGS[regT] = result;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 35:
    temp = mask(0, 31);
    result = temp & memory;
    result = (int)result;
    NEXT_STATE.REGS[regT] = result;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
    break;
  case 36:
    temp = mask(24, 31);
    result = temp & memory;
    result = result >> 24; 
    NEXT_STATE.REGS[regT] = result;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    return; 
  case 37:
    temp = mask(16, 31);
    result = temp & memory;
    result = result >> 16;
    NEXT_STATE.REGS[regT] = result;
    NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    return; 
  }
  
  return;
}

/* processes the I-type instructions */ 
void immediate(uint32_t instruction, unsigned convert){
  uint32_t temp = mask(0, 15);
  uint16_t value  = temp & instruction;
  unsigned regS, regT, temp2, result;
  /* sign extend the immediate value */
  /* gets the registers to be operated on */
  temp = mask(16, 20);
  temp2 = mask(21, 25);
  regS = temp2 & instruction;
  regT = temp & instruction;
  regS = regS >> 21;
  regT = regT >> 16;
  /* executes the appropriate instruction based on what was read from the instruction memory */ 
  switch(convert){
  case 8:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] + value;
    break;
    /* 8 and 9 are addi and addiu, they are the same in this project since we are ignoring oveflows */ 
  case 9:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] + value; 
    break;
  case 10:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] - value;
    if (result < 0){
      result = 1;
    }
    if (result >= 0){
      result = 0;
    }
    break;
    /* SLTI and SLTIU are the same for the same reason as ADDIU and ADDI */ 
  case 11:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] - value;
    if (result < 0) {
      result = 1;
    }
    if (result >= 0){
      result = 0;
    }
    break;
  case 12:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] & value;
    break;
  case 13:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] | value;
    break;
  case 14:
    value = (int16_t)value;
    result = CURRENT_STATE.REGS[regS] ^ value;
    break;
  case 15:
    value = (uint32_t)value; 
    result = (uint32_t)result; 
    result = value;
    result = result << 16; 
    break;
  }
  NEXT_STATE.REGS[regT] = result; 
  NEXT_STATE.PC = CURRENT_STATE.PC + 4; 
  return;
}

/* branch target address is determined by the instruction, then shifted 2 bits to the left and sign-extended
   if the given condition is true, then the program branches to that target address */ 
void branch(uint32_t instruction, unsigned convert){
  uint32_t temp = mask(0, 15);
  unsigned temp2, regS, regT;
  uint16_t target = temp & instruction;  
  /* shifts the target to the left twice */
  target = target << 2;
  /* sign extends the target */ 
  target = (int16_t)target; 
  /* gets the bits that represent each register in the branch instruction */
  temp = mask(16, 20);
  temp2 = mask(21, 25);
  regS = temp2 & instruction;
  regT = temp & instruction;
  regS = regS >> 21;
  regT = regT >> 16; 
  /* performs the appropriate comparison based on the instruction */
  switch (convert){
  case 4:
    if (CURRENT_STATE.REGS[regS] == CURRENT_STATE.REGS[regT]){
      NEXT_STATE.PC = target + CURRENT_STATE.PC;
      return; 
    }
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 5:
    if (CURRENT_STATE.REGS[regS] != CURRENT_STATE.REGS[regT]){
      NEXT_STATE.PC = target + CURRENT_STATE.PC;
      return;
    }
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break;
  case 6:
    if (CURRENT_STATE.REGS[regS] <= 0){
      NEXT_STATE.PC = target + CURRENT_STATE.PC;
      return;
    }
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  case 7:
    if (CURRENT_STATE.REGS[regS] >= 0){
      NEXT_STATE.PC = target + CURRENT_STATE.PC;
      return;
    }
    else
      NEXT_STATE.PC = CURRENT_STATE.PC + 4;
    break; 
  }
  return; 
}

/* 26-bit target is shifted left by 2 bits. the program unconditionally jumps to this calculated address */ 
void jump(uint32_t instruction, unsigned convert){
  uint32_t temp = mask(0, 25);
  unsigned target = temp & instruction;
  target = target << 2; 
  target -= 36; /* in order to jump to the correct PC value, subtract 36 from the PC as I copied the hex value
		   for each instruction directly from qtSpim. This meant that the target address passed into
		   the instructions like branch and jump were 36 ahead of where they should be as the hex 
		   values were copied from the data section in qtSpim. */
  NEXT_STATE.PC = target;
  if (convert == 3){
    NEXT_STATE.REGS[31] = CURRENT_STATE.PC + 4;
  }
  return;
}

/* main function that uses the above defined functions. */ 
void process_instruction()
{
    /* execute one instruction here. You should use CURRENT_STATE and modify
     * values in NEXT_STATE. You can call mem_read_32() and mem_write_32() to
     * access memory. */
  
  /* fetch the instruction using the current PC value */
  uint32_t instruction = mem_read_32(CURRENT_STATE.PC);
  
  /* gets bits 26-31 of the instruction */
  uint32_t temp = mask(26, 31);
  unsigned convert = temp & instruction;
  convert = convert >> 26;
  
  /* calls a certain function based on what instruction type it is */ 
  switch (convert){
  case 0:
    special(instruction, convert);
    break;
  case 1:
    regImm(instruction, convert);
    break;
  case 2:
    jump(instruction, convert);
    break;
  case 3:
    jump(instruction, convert);
    break;
  case 4:
    branch(instruction, convert);
    break;
  case 5:
    branch(instruction, convert);
    break;
  case 6:
    branch(instruction, convert);
    break;
  case 7:
    branch(instruction, convert);
    break;
  case 8:
    immediate(instruction, convert);
    break;
  case 9:
    immediate(instruction, convert);
    break;
  case 10:
    immediate(instruction, convert);
    break;
  case 11:
    immediate(instruction, convert);
    break;
  case 12:
    immediate(instruction, convert);
    break;
  case 13:
    immediate(instruction, convert);
    break;
  case 14:
    immediate(instruction, convert);
    break;
  case 15:
    immediate(instruction, convert);
    break;
  case 32:
    load(instruction, convert);
    break;
  case 33:
    load(instruction, convert);
    break;
  case 35:
    load(instruction, convert);
    break;
  case 36:
    load(instruction, convert);
    break;
  case 37:
    load(instruction, convert);
    break;
  case 40:
    store(instruction, convert);
    break;
  case 41:
    store(instruction, convert);
    break;
  case 43:
    store(instruction, convert);
    break; 
  }
  return;
}
